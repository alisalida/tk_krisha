import os
import openpyxl
from tkinter import *
from tkinter.ttk import Notebook, Frame
from Apt import Apt
from pathlib import Path
import webbrowser

def run_tkinter(wb):
    # Tkinter settings
    window = Tk()
    window.title("App n2")
    window.geometry('660x300')

    # Tabs
    tab_control = Notebook(window)
    tab1 = Frame(tab_control)
    tab_control.add(tab1, text='Квартиры')

    tab_control.pack(expand=1, fill='both')

    apt = Apt(tab1, wb)
    apt.start()

    window.mainloop()


if __name__ == '__main__':
    wb = openpyxl.Workbook()
    run_tkinter(wb)