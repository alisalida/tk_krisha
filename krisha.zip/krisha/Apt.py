import os
import openpyxl
import math
from tkinter import *
from tkinter.ttk import Combobox
from bs4 import BeautifulSoup
import requests
import re
import statistics
import webbrowser

class Apt:

    def __init__(self, tab, wb):
        self.tab = tab
        self.wb = wb
        self.cities = list(self.get_city_loc().keys())

    def get_city_loc(self):
        current_dir = os.getcwd()
        file_path = os.path.join(current_dir, '2', 'kr.xlsx')
        k_workbook = openpyxl.load_workbook(file_path, read_only=True)
        city_sheet = k_workbook["Cities"]
        self.cities = {}

        for sheet_row in city_sheet.iter_rows(min_row=2, min_col=1, max_row=city_sheet.max_row, max_col=4):
            if not sheet_row[0].value in self.cities:
                self.cities[sheet_row[0].value] = []

            self.cities[sheet_row[0].value].append({
                'city_code': sheet_row[1].value,
                'region_name': sheet_row[2].value,
                'region_code': sheet_row[3].value})
        return self.cities

    def updtcblist(self, city_combobox, region_combobox):
        city = city_combobox.get()
        regions = self.print_regions(city)
        region_combobox['values'] = regions
        region_combobox.current(0)

        # Retrieve the selected region name and corresponding region code
        selected_region_name = region_combobox.get()
        selected_region_code = self.get_selected_region_code(city, selected_region_name)
        print(f"Selected Region Code: {selected_region_code}")

    def get_selected_region_code(self, city, selected_region_name):
        city_loc = self.get_city_loc()
        if city in city_loc:
            regions = city_loc[city]
            for region in regions:
                if region['region_name'] == selected_region_name:
                    return region['region_code']
        return None

    def print_regions(self, city):
        city_loc = self.get_city_loc()
        regions = []

        if city in city_loc:
            regions = [region['region_name'] for region in city_loc[city]]

        return regions


    def start(self):
        tab = self.tab

        # Текст
        Label(tab, text='Город', width=14).grid(row=0)
        Label(tab, text='Район', width=14).grid(row=1)
        Label(tab, text='Год постройки', width=14).grid(row=2)
        Label(tab, text='Комнатность', width=14).grid(row=3)

        # Выбор города
        city = Combobox(tab, width=45)
        city['values'] = self.cities
        city.current(0)
        city.grid(row=0, column=1)

        city.bind("<<ComboboxSelected>>", lambda event: self.updtcblist(city, region))

        region = Combobox(tab, width=45)
        self.updtcblist(city, region)
        region.grid(row=1, column=1)

        year = Entry(tab)
        year.insert(-1, "2023")
        year.grid(row=2, column=1, sticky="ew")

        room = Combobox(self.tab, width=45)
        room['values'] = [1, 2, 3, 4, 5]
        room.current(0)
        room.grid(row=3, column=1)

        itog = Label(tab, text='', width=14, fg='green', font=('Arial', 11, 'normal'))
        itog.grid(row=6, column=0)

        Button(tab, text='Посчитать', width=10, command=lambda: self.calculate(
            city.get(), region.get(), float(year.get()), room.get(), itog)).grid(row=6, column=2)

        Button(tab, text='Показать', width=10, command=lambda: self.open_browser()).grid(row=6, column=3)


    def calculate(self, city, region, year, room, itog):
        self.m2s = []
        self.prices = []
        self.prices_m = []

        region_code = self.get_selected_region_code(city, region)
        print(region_code)
        if region_code is not None:
            try:
                for i in range(1, 6):
                    self.host = f'https://krisha.kz/prodazha/kvartiry/{region_code}/?das[house.year][from]={year}&das[house.year][to]={year}&das[live.rooms]={room}&page={i}'
                    request = requests.get(self.host)
                    soup = BeautifulSoup(request.text, 'html.parser')

                    div_element = soup.find('div', class_='a-search-empty')

                    if div_element is not None:
                        print('No items')

                    else:

                        items_soup = soup.find_all(class_='a-card__inc')

                        for item in items_soup:
                            try:
                                item_m = item.find('div', class_='a-card__header-left')
                                if item_m is not None:
                                    item_m = item_m.text
                                    item_m = re.search(r'\b(\d+)\s*м²\b', item_m)
                                    item_m = int(item_m.group(1))
                                    if item_m:
                                        self.m2s.append(item_m)

                                item_price = item.find('div', class_='a-card__price')
                                if item_price is not None:
                                    item_price = item_price.text
                                    item_price = ''.join(filter(str.isdigit, item_price))
                                    item_price = int(item_price)
                                    self.prices.append(item_price)

                                    self.prices_m2.append(round(item_price / item_m))
                            except AttributeError:
                                print('AttributeError')
                                pass

            except ConnectionError:
                print('ConnectionError')
                pass
            if len(self.prices)!=0 and len(self.prices_m)!=0:
                average_price = statistics.median(self.prices)
                average_price = format(round(average_price), ",d").replace(",", " ")
                avg_price = statistics.median(self.prices_m)
                avg_price = format(round(avg_price), ",d").replace(",", " ")
                itog.configure(text=f'Ср. стоимость\nна рынке:\n{average_price}тг\nЗа кв. метр:\n{avg_price}')
            else:
                itog.configure(text=f'Нет аналогов\nна рынке\nили проблема\nс сервером')

    def open_browser(self):
        webbrowser.open(self.host)